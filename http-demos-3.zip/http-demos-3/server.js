const express = require("express")
const bodyParser = require("body-parser")
const cookieParser = require("cookie-parser")
const session = require("express-session")
const commonRoutes=require("./routes/common-routes")
const productRoutes=require("./routes/product-routes")
const userroutes=require("./routes/user-routes")
var path=require("path")
// creating a express object
var app=new express();
app.set('views','views');
app.set('view engine',"pug")
app.use(express.static(path.resolve(__dirname,"public")))
//configure request handlers
app.use(cookieParser("mysecretkey"))
app.use(session({
}))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))
//routing
app.use("/",commonRoutes)
app.use("/products",productRoutes)
app.use("/user",userroutes)
module.exports=app
       