var mongoose=require("mongoose")
var UserSchema=mongoose.Schema({
    firstName:{type:String,minlength:3,required:true},
    email:{type:String, required:true},
    password:{type:String, minlength:8,required:true}
})
module.exports=mongoose.model('user',UserSchema)