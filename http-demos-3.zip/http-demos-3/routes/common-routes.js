const express=require("express")
var router=express.Router();
router.get("/",(req,res)=>{.0
    res.header("content-type","text/html").render("index")
})
router.get("/about",(req,res)=>{
    res.header("content-type","text/html").render("about")
})
router.get("/Contact",(req,res)=>{
    res.header("content-type","text/html").render("contact")
})
module.exports=router